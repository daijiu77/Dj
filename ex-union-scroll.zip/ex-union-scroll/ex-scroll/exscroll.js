// ex-scroll/exscroll.js
var exscrollObj = {
  data: {
    thisObj: null,
    raleX: 0,
    raleY: 0,
    timeStamp: 0,
    timeStamp1: 0,
    timeStampN: 0,
    moveUnit: 10,
    isTouch: false
  },
  setPos: function (x, y) {
    var x1 = this.data.pos.start.x;
    var y1 = this.data.pos.start.y;

    var x2 = this.data.pos.current.x;
    var y2 = this.data.pos.current.y;
    x2 = x2 + (x - x1);
    y2 = y2 + (y - y1);
    var obj = {};
    if (0 >= x2) {
      if ((0 - x2) <= this.data.dataContainerW) {
        obj.posX = x2;
      }
    }

    if (0 >= y2) {
      if ((0 - y2) <= this.data.dataContainerH) {
        obj.posY = y2;
      }
    }

    if ({} != obj) {
      this.setData(obj);
    }
  },
  /** 弹簧效果 有点bug **/
  spring: function(){
    var n = exscrollObj.data.timeStamp > exscrollObj.data.timeStamp1 ? exscrollObj.data.timeStamp - exscrollObj.data.timeStamp1 : 0;
    n = exscrollObj.data.timeStamp1 > exscrollObj.data.timeStamp ? exscrollObj.data.timeStamp1 - exscrollObj.data.timeStamp : 0;
    if(0 == n) return;
    var tArr = [];    
    var endTime = 1000;
    var t = endTime / n;
    var m = n - 1;
    t = parseInt(t);
    for(var i = 0; i < n;i++){
      if(m == i){
        tArr[i] = endTime;
      }
      else{
        tArr[i] = (i + 1) * t;
      }
    }
    var curr = exscrollObj.data.thisObj.data.pos.current;
    var raleX = exscrollObj.data.raleX;
    var raleY = exscrollObj.data.raleY;
    raleX = 0 > raleX ? (0 - raleX) : raleX;
    raleY = 0 > raleY ? (0 - raleY) : raleY;
    if(raleX > raleY){
      var len = tArr.length;
      if(0 != raleX){
        var r = (raleY / raleX) * len;
        raleY = parseInt(r);
      }
      raleX = len;      
    }
    else if (raleX < raleY){
      var len = tArr.length;
      if (0 != raleY) {
        var r = (raleX / raleY) * len;
        raleX = parseInt(r);
      }
      raleY = len;
    }
    else if(0 == raleX){
      return;
    }
    else{
      var len = tArr.length;
      raleX = len;
      raleY = len;
    }
    this.spring.tArr = tArr;
    this.spring.i = 0;
    this.spring.len = tArr.length;
    this.spring.pos = { x: curr.x, y: curr.y};
    this.spring.rale = { x: raleX, y: raleY };
    this.spring.unit = exscrollObj.data.moveUnit;
    this.spring.exec = function(){
      if (exscrollObj.data.isTouch) return;
      if(this.i >= this.len) return;
      var tm = this.tArr[this.i];
      setTimeout(function(obj){
        var x = obj.pos.x;
        var y = obj.pos.y;
        if((obj.rale.x - 1) <= obj.i){
          x = x + ((obj.i + 1) * obj.unit);
        }

        if ((obj.rale.y - 1) <= obj.i) {
          y = y + ((obj.i + 1) * obj.unit);
        }
        exscrollObj.setPos.apply(exscrollObj.data.thisObj, [x, y]);
        obj.i++;        
        obj.exec();
      },tm,this);
    }
    this.spring.exec();
  }
}
Component({
  properties: {
    exscrollId: {
      type: String,
      value: 'exscroll'
    },
    width:{
      type: Number,
      value: 300
    },
    height:{
      type: Number,
      value: 100
    },    
    rowHeight:{
      type: Number,
      value: 40
    },   
    lineHeight: { //灰线高度
      type: Number,
      value: 1
    },
    adapter: {
      type: Object,
      value: {
        keyName: 'id',
        headCols: [], 
        //smart: 如果数据值里包含 html 标签，则需要开启智能识别,默认值为 false，但这样会影响性能。
        //[{ title: '第一列', name: 'fleid1', width: 80, titleAlign: 'center', dataAlign: 'center', color: 'black', bgColor: 'white', fontSize: 12, smart: false}, { title: '第二列', name: 'fleid2', width: 40, titleAlign: 'center', dataAlign: 'center', color: 'black', bgColor: 'white', fontSize: 12, smart: false}, { title: '第三列', name: 'fleid3', width: 40, titleAlign: 'center', dataAlign: 'center', color: 'black', bgColor: 'white', fontSize: 12, smart: false}]
        dataStore: [],
        //[{ id: { img: '', val: 1, smart: false}, field1: { img: '', val: '第一行', smart: false}, field2: { img: '/images/01.png', imgWidth: 10, imgHeight: 10, val: 32.06, color: 'black', fontSize: 12, textWidth: 60, smart: false}, field3: { img: '/images/02.png', imgWidth: 10, imgHeight: 10, val: -0.27, color: 'black', fontSize: 12, textWidth: 60, smart: false} }, { id: { img: '', val: 2, smart: false}, field1:  { img: '', val: '第二行', smart: false}, field2: { img: '/images/01.png', imgWidth: 10, imgHeight: 10, val: 12.65, color: 'black', fontSize: 12, textWidth: 60, smart: false}, field3: { img: '/images/01.png', imgWidth: 10, imgHeight: 10, val: 66.4, color: 'black', bgColor: 'white', fontSize: 12, textWidth: 60, smart: null} }]
        /***************************************************************/
        //注： 当 img 属性值为空时, imgWidth,imgHeight可省略,反之必须存在,且有值。但 color,bgColor,fontSize,textWidth 总是可省略, 其中 textWidth 在属性img有值时才有效
        //smart: 如果数据值里包含 html 标签，则需要开启智能识别,数据里smart默认值为 null，但这样会影响性能。(数据里的smart优先权大于headCols里的smart,当数据里的smart==null时,采用headCols里的smart)
        /***************************************************************/
        init: function(e){} //e = {showData : function(){}}
      }
    },
    events:{
      type:Object,
      value:{
        firstColClick:function(e, id){},
        dataRowClick:function(e, id){}
      }
    }
  },
  data: { 
    posX: 0,
    posY: 0,
    firstColWidth: 60,
    dataAreaWidth: 60,
    dataAreaHeight: 100,
    pos:{
      start: { x: 0, y: 0},
      current: { x: 0, y: 0}
    },
    keyName: 'id',
    headCols: [{ title: '', name: 'fleid1', width: 40, titleAlign: 'center', dataAlign: 'center', color: 'black', bgColor: 'white', fontSize: 12, smart: false}],
    dataStore:[],
    dataContainerW: 0,
    dataContainerH: 0
  },
  methods: { 
    firstColClick: function(e){
      if (null != this.data.events) {
        if (this.data.events.firstColClick instanceof Function) {
          var id = e.target.id;
          if (0 == id.length) {
            id = e.currentTarget.id;
          }
          this.data.events.firstColClick.apply(this,[e, id]);
        }
      }
    },
    dataRowClick: function (e) {
      if (null != this.data.events) {
        if (this.data.events.dataRowClick instanceof Function) {
          var id = e.target.id;
          if (0 == id.length) {
            id = e.currentTarget.id;
          }
          this.data.events.dataRowClick.apply(this, [e, id]);
        }
      }
    },
    extouchstart: function(e) {
      exscrollObj.data.isTouch = true;
      var x = e.changedTouches[0].pageX;
      var y = e.changedTouches[0].pageY;
      this.data.pos.start.x = x;
      this.data.pos.start.y = y;

      this.data.pos.current.x = this.data.posX;
      this.data.pos.current.y = this.data.posY;
      //console.log(e);
    },
    extouchend: function(e){            
      var x = e.changedTouches[0].pageX;
      var y = e.changedTouches[0].pageY;
      exscrollObj.setPos.apply(this, [x, y]);
      if (0 != x) exscrollObj.data.raleX = this.data.pos.start.x / x;
      if (0 != y) exscrollObj.data.raleY = this.data.pos.start.y / y;

      this.data.pos.start.x = x;
      this.data.pos.start.y = y;
      
      this.data.pos.current.x = this.data.posX;
      this.data.pos.current.y = this.data.posY;
      exscrollObj.data.isTouch = false;
      //exscrollObj.spring();
    },    
    extouchmove: function(e){
      //console.log(e);
      var x = e.changedTouches[0].pageX;
      var y = e.changedTouches[0].pageY;
      
      if (0 == exscrollObj.data.timeStampN){
        exscrollObj.data.timeStampN = 1;
        exscrollObj.data.timeStamp = e.timeStamp;
      }
      else{
        exscrollObj.data.timeStampN = 0;
        exscrollObj.data.timeStamp1 = e.timeStamp;
      }
      exscrollObj.setPos.apply(this,[x, y]);
    }
  },
  ready: function(){
    if(null != this.data.adapter.init){
      if (this.data.adapter.init instanceof Function){
        var exec = {
          thisObj: this,
          showData: function () {
            var headCols = this.thisObj.data.adapter.headCols;
            var len = headCols.length;
            var w = 0;
            //smart: 如果数据值里包含 html 标签，则需要开启智能识别，但这样会影响性能。(数据里的smart优先权大于headCols里的smart)
            var a = { title: '', name: 'fleid1', width: 80, titleAlign: 'center', dataAlign: 'center', color: 'black', bgColor: 'white', fontSize: 14, smart: false};
            for (var i = 0; i < len; i++) {
              for(var k in a){
                if (null == headCols[i][k]){
                  headCols[i][k] = a[k];
                }
              }
              if (0 < i) {
                var n = headCols[i].width;
                n = parseInt(n);
                w += n;
              }              
            }
            var obj = {};
            obj.dataAreaWidth = w;
            this.thisObj.data.dataAreaWidth = obj.dataAreaWidth;

            obj.rowHeight = parseInt(this.thisObj.data.rowHeight);
            this.thisObj.data.rowHeight = obj.rowHeight;

            var dts = this.thisObj.data.adapter.dataStore;
            len = dts.length;
            //smart: 如果数据值里包含 html 标签，则需要开启智能识别，但这样会影响性能。(数据里的smart优先权大于headCols里的smart)
            a = { img: '', imgWidth: 10, imgHeight: 10, val: '', color: 'black', bgColor: 'white', fontSize: 14, textWidth: 60, smart: null};

            for(var i=0;i<len;i++){
              var ele = dts[i];              
              for(var k in ele){
                for (var k1 in a) {
                  if (null == ele[k][k1]) {
                    ele[k][k1] = a[k1];
                  }
                }

                if(null == ele[k].img){
                  ele[k].img = '';
                }
              }
            }
            var h1 = parseInt(this.thisObj.data.lineHeight);
            h1 = 0 == h1 ? 1 : h1;
            var n = obj.rowHeight * len + (len - 1) * h1; //len - 1 为数据行之间的所有灰线高
            obj.lineHeight = h1;
            obj.dataAreaHeight = n;
            this.thisObj.data.dataAreaHeight = obj.dataAreaHeight;

            w = headCols[0].width;
            obj.firstColWidth = parseInt(w);
            this.thisObj.data.firstColWidth = obj.firstColWidth;

            var key = this.thisObj.data.adapter.keyName;
            obj['keyName'] = null == key ? 'id' : key;
            
            obj['headCols'] = [{ title: '', name: 'fleid1', width: 40, titleAlign: 'center', dataAlign: 'center', color: 'black', bgColor: 'white', fontSize: 12 }];                     
            
            var dW = obj.dataAreaWidth - (this.thisObj.data.width - headCols[0].width);
            var dH = obj.dataAreaHeight - (this.thisObj.data.height - this.thisObj.data.rowHeight - this.thisObj.data.lineHeight);     
            this.thisObj.data.dataContainerW = dW;
            this.thisObj.data.dataContainerH = dH;
            obj.dataContainerW = dW;
            obj.dataContainerH = dH;
            obj.posX = 0;
            obj.posY = 0;
            obj['dataStore'] = [];
               
            //console.log('w: '+dW+' h: '+dH);
            this.thisObj.setData(obj);

            obj = {};
            obj['headCols'] = headCols; 
            obj['dataStore'] = dts;
            this.thisObj.setData(obj);
          }
        }
        this.data.adapter.init(exec);
      }      
    }

    exscrollObj.data.thisObj = this;
  }
})