// ex-scroll/childs/index.js
var childsIndex = {
  resetVal: function(v, list){
    var len = list.length;
    for(var i = 0; i < len; i++){
      if (-1 != v.indexOf(list[i].sign)) {
        var sign = list[i].sign;
        var txt = list[i].txt;
        txt = childsIndex.resetVal(txt, list);
        v = v.replace(sign, txt);
      }
    }    
    return v;
  }
}
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    val:{
      type: String,
      value: ''
    }
  },
  data: {
    vDatas: [], //{tag: '', style: '', val: ''}
    vData: ''
  },
  methods: {},
  ready: function() {
    if(null != this.data.val){
      //[a-z]\=[\'\"]([^\'\"]+)[\'\"]
      var s = this.data.val;
      s = null == s ? '' : s;
      var rg = /\<([a-z]+)[^\<]*\>([^\<\>]*)\<\/[a-z]+\>/i;
      var arr = rg.exec(s);
      if(null == arr){
        this.data.vData = s;
        var obj = {};
        obj.vData = s;
        this.setData(obj);
      }
      else{
        var list = []; //{tag: '', sign: '', txt: '', val: ''}
        var i = 0;        
        while(null != arr){
          var txt = arr[0];
          var tag = arr[1];
          var val = arr[2];
          var sign = '{sign' + i + '}';
          list[i] = { tag: tag, sign: sign, txt: txt, val: val};
          s = s.replace(txt, sign);
          arr = rg.exec(s);
          i++;
        }

        rg = /([a-z]+)\=[\'\"]([^\'\"]+)[\'\"]/i;
        arr = this.data.vDatas;
        var len = list.length;
        for(var i = 0; i<len; i++){
          if (-1 != s.indexOf(list[i].sign)){
            var tag = list[i].tag;            
            var txt = list[i].txt;
            var val = list[i].val;
            var obj = {};
            obj.tag = tag.toString().toLowerCase();
            var arr1 = rg.exec(txt);
            if(null != arr1){
              while(null != arr1){
                var k1 = arr1[1];
                var v1 = arr1[2];
                obj[k1] = v1;
                txt = txt.replace(arr1[0],'');
                arr1 = rg.exec(txt);
              }
            }
            if (null == obj.style) obj.style = 'background-color:none;';
            obj.val = childsIndex.resetVal(val, list);            
            arr[arr.length] = obj;
          }
        }
        var obj1 = {};
        obj1.vDatas = arr;
        this.setData(obj1);
      }
    }
  }
})
