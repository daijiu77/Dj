// pages/scroll/index.js

var scrollIndex = {
  temps:{},
  methods:{
    loadData: function(){
      if (null == scrollIndex.temps.thisObj) return;
      setTimeout(function () {
        var myObj = scrollIndex.temps.thisObj;
        myObj.data.adapter.headCols = [];

        var arr = myObj.data.adapter.dataStore;
        var carr = myObj.data.adapter.headCols;
        var dts = [23, 23, 66, 51, -9.5, 12.03, -16.27, 23, 17, -18.9, -9.07, 15, 15.02, 4.9, 7, 1];
        var len = dts.length;
        //下面初始为列头
        for (var i = 0; i < len; i++) {
          var n = i + 1;
          //smart: 如果数据值里包含 html 标签，则需要开启智能识别,默认值为 false，但这样会影响性能。
          //{ title: '第1列', name: 'fleid1', width: 40, titleAlign: 'center', dataAlign: 'center', color: 'black', bgColor: 'white', fontSize: 12, smart: false }
          var ele = { title: '第' + n + '列', name: 'field' + n, width: 80, titleAlign: 'center', dataAlign: 'center', smart: false };
          carr[carr.length] = ele;
        }

        len = 50;
        //下面生成数据
        for (var i = 0; i < len; i++) {
          var arr1 = [23, 23, 66, 51, -9.5, 12.03, -16.27, 23, 17, -18.9, -9.07, 15, 15.02, 4.9, 7, 1];
          var ele = {};
          var n = 1;
          ele.id = { img: '', val: (i + 1) };
          ele['field1'] = { img: '', val: '第' + (i + 1) + '行' };
          var len1 = arr1.length;
          for (var x = 0; x < len1; x++) {
            var rnd = Math.random() * 30;
            rnd = parseInt(rnd);
            var v = arr1[x] + rnd;
            v = v.toFixed(2);
            var img = '/images/icons/datarise.png';
            if (0 > v) img = '/images/icons/datadecline.png';
            n++;
            //每一个字段对应一个json对象, 例：{username:{img:'',val:''},age:{img:'',val:''}}  
            //{ img: '/images/01.png', imgWidth: 10, imgHeight: 10, val: 66.4, color: 'black', bgColor: 'white', fontSize: 12, textWidth: 60, smart: null}
            //注： 当 img 属性值为空时, imgWidth,imgHeight可省略,反之必须存在,且有值。但 color,bgColor,fontSize,textWidth 总是可省略, 其中 textWidth 在属性img有值时才有效
            //smart: 如果数据值里包含 html 标签，则需要开启智能识别,数据里smart默认值为 null，但这样会影响性能。(数据里的smart优先权大于headCols里的smart,当数据里的smart==null时,采用headCols里的smart)
            ele['field' + n] = { img: img, imgWidth: 10, imgHeight: 10, val: v, color: 'black', bgColor: 'white', fontSize: 12, textWidth: 60, smart: null };
          }
          arr[arr.length] = ele;
        }
        myObj.setData({ adapter: myObj.data.adapter });
        scrollIndex.temps.gv.showData();
      }, 100);
    }
  }
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    adapter: {
      keyName: 'id',
      headCols: [],
      dataStore: [],
      init: function (e) {
        scrollIndex.temps.gv = e;
        scrollIndex.methods.loadData();
      }
    },
    events: {
      firstColClick: function (e, id) {
        console.log('id: ' + id);
      },
      dataRowClick: function (e, id) {
        console.log('id: ' + id);
      }
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    scrollIndex.temps.thisObj = this;
    var h = wx.getSystemInfoSync().windowHeight;
    var w = wx.getSystemInfoSync().windowWidth;
    var obj = {};
    obj.width = w;
    obj.height = h -70;
    this.setData(obj);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})